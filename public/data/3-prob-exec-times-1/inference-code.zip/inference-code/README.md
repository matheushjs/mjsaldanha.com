Main file is `inference.r`

Run in your terminal:

```
R
> source("inference.r");
```

It should run the experiments right away.

Modify the final lines of file `inference.r` to perform the desired experiments.
